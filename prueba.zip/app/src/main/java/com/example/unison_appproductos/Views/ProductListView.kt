package com.example.unison_appproductos.Views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit // Icono de modificar
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.unison_appproductos.ViewModels.ProductoViewModel
import com.example.unison_appproductos.Navigation.NavDestinations
import com.example.unison_appproductos.dialogs.DeleteConfirmationDialog
import com.example.unison_appproductos.model.Producto

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductListView(viewModel: ProductoViewModel, modifier: Modifier = Modifier, navController: NavController) {
    var showDeleteDialog by remember { mutableStateOf<Producto?>(null) } // Producto a eliminar

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lista de Productos") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver a HomeView")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate(NavDestinations.ProductForm) },
                content = { Icon(Icons.Default.Add, contentDescription = "Añadir Producto") }
            )
        }
    ) { contentPadding ->
        Column(
            modifier = Modifier
                .padding(contentPadding)
                .background(Color(0xFF697565))
                .fillMaxSize()
        ) {
            val estado = viewModel.estado.collectAsState().value

            if (estado.estaCargando) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF697565))
                }
            } else {
                LazyColumn {
                    items(estado.productos) { producto ->
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth()
                                .background(Color(0xFF3C3D37), shape = MaterialTheme.shapes.medium)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "${producto.nombre} ($${producto.precio} MXN)",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFECDFCC)
                            )
                            Text(
                                text = producto.descripcion,
                                color = Color(0xFFECDFCC),
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Fecha de creación: ${producto.fechaRegistro}",
                                color = Color(0xFFECDFCC),
                                fontSize = 12.sp
                            )

                            Row {
                                IconButton(
                                    onClick = {
                                        navController.navigate("${NavDestinations.ProductForm}/${producto.id}")
                                    }
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Modificar", tint = Color(0xFFECDFCC))
                                }

                                IconButton(
                                    onClick = { showDeleteDialog = producto }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color(0xFFECDFCC))
                                }
                            }
                        }
                    }
                }

                showDeleteDialog?.let { producto ->
                    DeleteConfirmationDialog(
                        onDismiss = { showDeleteDialog = null },
                        onConfirm = {
                            viewModel.delete(producto)
                            showDeleteDialog = null
                        },
                        productoNombre = producto.nombre
                    )
                }
            }
        }
    }
}
