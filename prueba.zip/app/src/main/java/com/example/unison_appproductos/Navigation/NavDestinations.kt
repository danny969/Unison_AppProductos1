package com.example.unison_appproductos.Navigation

object NavDestinations {
    const val Home = "home"
    const val ProductList = "product_list"
    const val ProductForm = "product_form"
    const val PresentationCard = "presentation_card"
}
